# Video Editor Tool (DSA-driven)

A small Flask web app that edits a video *timeline* using clip metadata only
(labels, in/out times, durations), with no media dependencies.

## Run

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py                                       # open http://127.0.0.1:5000
python -m pytest                                    # run the tests
```

## Layout

```
video_editor/
├── app.py                 Flask app: JSON API + serves the page
├── requirements.txt       Flask, pytest
├── editor/
│   ├── timeline.py        array-backed timeline, prefix sums, binary search
│   ├── history.py         command pattern + two stacks (undo/redo)
│   ├── jobs.py            heap-based priority queue for export jobs
│   └── project.py         Project (ties it together) + in-memory ProjectStore
├── templates/index.html   single page UI
├── static/{app.js,style.css}
└── tests/                 timeline ops, undo/redo, export queue, API
```

## Which structure does what

| Feature | Structure | Why | Cost |
|---|---|---|---|
| Ordered clips, reorder, delete | array-backed list | cheap indexing + full-timeline rendering | O(1) read, O(n) edit |
| Timeline positions | prefix-sum array | sorted by construction, enables binary search | O(n) rebuild per edit |
| "Clip at time t", split | binary search (`bisect`) | sorted offsets | O(log n) |
| Undo / redo | two stacks of Command objects (`deque`) | most recent edit is undone first | O(1) |
| Export jobs | binary heap (`heapq`) + sequence tiebreak | urgent jobs first, FIFO within a priority | O(log n) |

## Time model

`start`/`end` are a clip's in/out points in its source media. Clips play
back-to-back, so a clip's timeline position is derived from the clips before it.
Reordering, trimming and deleting therefore re-flow everything after them.
"Split at timestamp" and "which clip is at t" use *timeline* time.

## Notes

* Projects live in memory and reset when the server restarts.
* Export is simulated: it produces an EDL-style text listing of the timeline as
  it was when the job was queued.
* To add real video later, give `Clip` a `source` path and have
  `ExportQueue.process_next` call ffmpeg with the snapshot's clip list.

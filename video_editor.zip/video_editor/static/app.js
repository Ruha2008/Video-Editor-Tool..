"use strict";
let projectId = null;
const $ = (id) => document.getElementById(id);

function el(tag, props = {}, ...kids) {              // text always goes in via textContent (no XSS)
  const node = document.createElement(tag);
  Object.assign(node, props);
  for (const k of kids) node.append(k);
  return node;
}
const fmt = (s) => (Math.round(s * 1000) / 1000).toString() + "s";

function say(text, isErr = false) {
  const m = $("msg"); m.textContent = text || ""; m.className = isErr ? "err" : "";
}

async function api(method, path, body) {
  const res = await fetch(path, {
    method, headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

// Run an API call, re-render on success, show the error on failure.
async function act(method, path, body, okMsg = "") {
  try {
    const state = await api(method, path, body);
    say(okMsg); render(state); return state;
  } catch (e) { say(e.message, true); }
}
const base = () => `/api/projects/${projectId}`;

async function loadProjects(selectId) {
  const list = await api("GET", "/api/projects");
  const sel = $("project-select");
  sel.replaceChildren(el("option", { value: "", textContent: list.length ? "Open project…" : "No projects yet" }));
  for (const p of list) sel.append(el("option", { value: p.id, textContent: p.name }));
  if (selectId) sel.value = selectId;
}

async function openProject(id) {
  projectId = id;
  if (!id) { $("editor").hidden = true; return; }
  try { render(await api("GET", base())); } catch (e) { say(e.message, true); }
}

function render(s) {
  $("editor").hidden = false;
  $("title").textContent = s.name;
  $("total").textContent = fmt(s.total_duration);
  $("undo").disabled = !s.can_undo; $("redo").disabled = !s.can_redo;

  // proportional overview bar
  $("bar").replaceChildren(...s.clips.map((c) => {
    const seg = el("div", { className: "seg", textContent: c.label, title: `${c.label} (${fmt(c.duration)})` });
    seg.style.flex = `${c.duration} 1 0`; return seg;
  }));

  // clip table
  const last = s.clips.length - 1;
  $("empty").hidden = s.clips.length > 0;
  $("clips").replaceChildren(...s.clips.map((c) => {
    const inS = el("input", { type: "number", step: "0.001", min: "0", value: c.start, ariaLabel: "new start" });
    const inE = el("input", { type: "number", step: "0.001", min: "0", value: c.end, ariaLabel: "new end" });
    const up = el("button", { className: "ghost", textContent: "↑", title: "Move earlier", disabled: c.index === 0 });
    const dn = el("button", { className: "ghost", textContent: "↓", title: "Move later", disabled: c.index === last });
    const trim = el("button", { className: "ghost", textContent: "Trim" });
    const del = el("button", { className: "ghost", textContent: "Delete" });
    up.onclick = () => act("POST", `${base()}/clips/${c.id}/move`, { to_index: c.index - 1 });
    dn.onclick = () => act("POST", `${base()}/clips/${c.id}/move`, { to_index: c.index + 1 });
    trim.onclick = () => act("POST", `${base()}/clips/${c.id}/trim`, { start: inS.value, end: inE.value });
    del.onclick = () => act("DELETE", `${base()}/clips/${c.id}`);
    return el("tr", {},
      el("td", { textContent: c.index + 1 }),
      el("td", { textContent: c.label }),
      el("td", {}, inS, " → ", inE),
      el("td", { textContent: fmt(c.duration) }),
      el("td", { textContent: `${fmt(c.timeline_start)} – ${fmt(c.timeline_end)}` }),
      el("td", {}, el("div", { className: "row" }, up, dn, trim, del)));
  }));

  $("undo-list").replaceChildren(...s.undo_stack.map((t) => el("li", { textContent: t })));
  $("redo-list").replaceChildren(...s.redo_stack.map((t) => el("li", { textContent: t })));

  // export queue
  const pri = $("priority"); const keep = pri.value || "3";
  pri.replaceChildren(...Object.entries(s.priorities).map(([k, v]) => el("option", { value: k, textContent: v })));
  pri.value = keep;
  $("process").disabled = s.export_pending.length === 0;
  $("pending").replaceChildren(...s.export_pending.map((j) =>
    el("li", { textContent: `${j.name} [${j.priority_name}] – ${j.clip_count} clips, ${fmt(j.total)}` })));
  $("done").replaceChildren(...s.export_done.map((j) =>
    el("div", {}, el("strong", { textContent: j.name }), el("pre", { textContent: j.result }))));
}

$("new-project").onsubmit = async (e) => {
  e.preventDefault();
  try {
    const p = await api("POST", "/api/projects", { name: $("project-name").value });
    $("project-name").value = ""; await loadProjects(p.id); say("Project created."); render(p); projectId = p.id;
  } catch (err) { say(err.message, true); }
};
$("project-select").onchange = (e) => openProject(e.target.value);
$("undo").onclick = () => act("POST", `${base()}/undo`);
$("redo").onclick = () => act("POST", `${base()}/redo`);

$("add-form").onsubmit = async (e) => {
  e.preventDefault(); const f = e.target;
  const s = await act("POST", `${base()}/clips`, { label: f.label.value, start: f.start.value, end: f.end.value });
  if (s) f.reset();
};
$("split-form").onsubmit = async (e) => {
  e.preventDefault(); const s = await act("POST", `${base()}/split`, { at: e.target.at.value });
  if (s) e.target.reset();
};
$("lookup-form").onsubmit = async (e) => {
  e.preventDefault();
  try {
    const r = await api("GET", `${base()}/lookup?t=${encodeURIComponent(e.target.t.value)}`);
    $("lookup-result").textContent = `Clip #${r.index + 1} "${r.label}", ${fmt(r.seconds_into_clip)} into it.`;
    say("");
  } catch (err) { $("lookup-result").textContent = ""; say(err.message, true); }
};
$("export-form").onsubmit = async (e) => {
  e.preventDefault(); const f = e.target;
  await act("POST", `${base()}/exports`, { priority: f.priority.value, name: f.name.value }, "Export queued.");
};
$("process").onclick = () => act("POST", `${base()}/exports/process`, undefined, "Processed the next export job.");

loadProjects();

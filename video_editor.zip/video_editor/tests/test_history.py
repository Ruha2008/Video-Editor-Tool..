import pytest

from editor.history import History
from editor.jobs import ExportQueue
from editor.project import Project
from editor.timeline import TimelineError


def snap(p):
    return [(c.id, c.label, c.start, c.end) for c in p.timeline]


@pytest.fixture
def project():
    p = Project("p1", "demo")
    p.add_clip("A", 0, 4)
    p.add_clip("B", 10, 16)
    p.add_clip("C", 2, 5)
    return p


def test_undo_redo_every_operation_type(project):
    ops = [
        lambda p: p.add_clip("D", 0, 2, index=1),
        lambda p: p.delete_clip(p.timeline[0].id),
        lambda p: p.move_clip(p.timeline[0].id, 2),
        lambda p: p.trim_clip(p.timeline[1].id, end=3),
        lambda p: p.split_at(1),
    ]
    base_depth = len(project.history.undo_labels())   # the fixture's 3 adds
    states = [snap(project)]
    for op in ops:
        op(project)
        states.append(snap(project))
    assert len(set(map(tuple, states))) == len(states)   # every op changed something

    for expected in reversed(states[:-1]):                # undo all the way back
        project.undo()
        assert snap(project) == expected
    assert len(project.history.undo_labels()) == base_depth
    assert len(project.history.redo_labels()) == len(ops)

    for expected in states[1:]:                           # redo all the way forward
        project.redo()
        assert snap(project) == expected
    assert not project.history.can_redo


def test_redo_of_split_reuses_same_ids(project):
    project.split_at(7)
    after = snap(project)
    project.undo()
    project.redo()
    assert snap(project) == after


def test_new_edit_clears_redo_stack(project):
    project.delete_clip(project.timeline[0].id)
    project.undo()
    assert project.history.can_redo
    project.add_clip("Z", 0, 1)
    assert not project.history.can_redo
    with pytest.raises(TimelineError):
        project.redo()


def test_stack_order_is_lifo(project):
    assert project.history.undo_labels()[0] == "Add 'C'"
    project.undo()
    assert project.history.redo_labels() == ["Add 'C'"]
    assert project.history.undo_labels()[0] == "Add 'B'"


def test_failed_edit_is_not_recorded(project):
    depth = len(project.history.undo_labels())
    with pytest.raises(TimelineError):
        project.split_at(4)
    assert len(project.history.undo_labels()) == depth


def test_undo_with_empty_history():
    p = Project("p", "x")
    with pytest.raises(TimelineError):
        p.undo()


def test_history_is_bounded():
    p = Project("p", "x")
    p.history = History(limit=3)
    for i in range(10):
        p.add_clip(f"c{i}", 0, 1)
    assert len(p.history.undo_labels()) == 3


def test_export_queue_priority_then_fifo(project):
    j1 = project.queue_export(3, "normal-1")
    j2 = project.queue_export(1, "urgent")
    j3 = project.queue_export(3, "normal-2")
    order = [project.process_next_export().name for _ in range(3)]
    assert order == ["urgent", "normal-1", "normal-2"]
    with pytest.raises(TimelineError):
        project.process_next_export()


def test_export_uses_snapshot_and_validates(project):
    project.queue_export(2, "snap")
    project.delete_clip(project.timeline[0].id)          # edit after queueing
    job = project.process_next_export()
    assert job.status == "done" and "001  A" in job.result
    with pytest.raises(TimelineError):
        project.queue_export(9)
    with pytest.raises(TimelineError):
        Project("e", "empty").queue_export()

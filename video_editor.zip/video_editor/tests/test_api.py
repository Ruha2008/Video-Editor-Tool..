import pytest

from app import create_app


@pytest.fixture
def client():
    return create_app().test_client()


def test_full_workflow(client):
    pid = client.post("/api/projects", json={"name": "Demo"}).get_json()["id"]
    base = f"/api/projects/{pid}"
    for label, s, e in [("Intro", 0, 5), ("Main", 10, 30)]:
        assert client.post(f"{base}/clips", json={"label": label, "start": s, "end": e}).status_code == 201

    state = client.get(base).get_json()
    assert [c["label"] for c in state["clips"]] == ["Intro", "Main"]
    assert state["total_duration"] == 25

    r = client.get(f"{base}/lookup?t=12").get_json()
    assert r["label"] == "Main" and r["seconds_into_clip"] == 7

    assert client.post(f"{base}/split", json={"at": 12}).status_code == 200
    cid = client.get(base).get_json()["clips"][0]["id"]
    assert client.post(f"{base}/clips/{cid}/move", json={"to_index": 2}).status_code == 200
    assert client.post(f"{base}/clips/{cid}/trim", json={"end": 2}).status_code == 200
    assert client.delete(f"{base}/clips/{cid}").status_code == 200

    assert client.post(f"{base}/undo").get_json()["can_redo"] is True
    assert client.post(f"{base}/redo").status_code == 200

    assert client.post(f"{base}/exports", json={"priority": 1}).status_code == 201
    done = client.post(f"{base}/exports/process").get_json()["export_done"]
    assert len(done) == 1


def test_errors_are_json(client):
    assert client.get("/api/projects/nope").status_code == 404
    assert client.post("/api/projects", json={"name": " "}).status_code == 400
    pid = client.post("/api/projects", json={"name": "x"}).get_json()["id"]
    base = f"/api/projects/{pid}"
    bad = client.post(f"{base}/clips", json={"label": "a", "start": "x", "end": 1})
    assert bad.status_code == 400 and "error" in bad.get_json()
    assert client.post(f"{base}/clips", json={"label": "a", "start": 5, "end": 1}).status_code == 400
    assert client.post(f"{base}/undo").status_code == 400
    assert client.delete(f"{base}/clips/zzz").status_code == 404


def test_index_page(client):
    assert b"Video Editor Tool" in client.get("/").data

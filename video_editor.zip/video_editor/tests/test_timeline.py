import pytest

from editor.history import History, AddClip
from editor.project import Project
from editor.timeline import Clip, Timeline, TimelineError, ClipNotFound


def labels(p):
    return [c.label for c in p.timeline]


@pytest.fixture
def project():
    p = Project("p1", "demo")
    p.add_clip("A", 0, 4)     # timeline 0-4
    p.add_clip("B", 10, 16)   # timeline 4-10
    p.add_clip("C", 2, 5)     # timeline 10-13
    return p


def test_clip_validation():
    with pytest.raises(TimelineError):
        Clip("x", "", 0, 1)
    with pytest.raises(TimelineError):
        Clip("x", "a", 5, 5)
    with pytest.raises(TimelineError):
        Clip("x", "a", -1, 5)
    with pytest.raises(TimelineError):
        Clip("x", "a", 0, "abc")


def test_layout_is_back_to_back(project):
    lay = project.timeline.layout()
    assert [(c["timeline_start"], c["timeline_end"]) for c in lay] == [(0, 4), (4, 10), (10, 13)]
    assert project.timeline.total_duration == 13


def test_find_at_binary_search(project):
    tl = project.timeline
    assert tl.find_at(0)[1].label == "A"
    assert tl.find_at(3.999)[1].label == "A"
    assert tl.find_at(4)[1].label == "B"          # boundary belongs to the later clip
    i, clip, into = tl.find_at(11.5)
    assert (i, clip.label, into) == (2, "C", 1.5)
    for bad in (-0.1, 13, 99):
        with pytest.raises(TimelineError):
            tl.find_at(bad)
    with pytest.raises(TimelineError):
        Timeline().find_at(0)


def test_insert_at_index(project):
    project.add_clip("X", 0, 1, index=1)
    assert labels(project) == ["A", "X", "B", "C"]
    with pytest.raises(TimelineError):
        project.add_clip("Y", 0, 1, index=9)


def test_move_reflows_positions(project):
    cid = project.timeline[2].id          # C
    project.move_clip(cid, 0)
    assert labels(project) == ["C", "A", "B"]
    assert [c["timeline_start"] for c in project.timeline.layout()] == [0, 3, 7]
    with pytest.raises(TimelineError):
        project.move_clip(cid, 5)


def test_trim_changes_duration_and_following_clips(project):
    b = project.timeline[1].id
    project.trim_clip(b, start=12)                  # B now 12-16 -> 4s
    assert project.timeline[1].duration == 4
    assert project.timeline.total_duration == 11
    with pytest.raises(TimelineError):
        project.trim_clip(b, start=20)              # start past end
    with pytest.raises(TimelineError):
        project.trim_clip(b)                        # nothing changes


def test_split_at_timestamp(project):
    project.split_at(7)                             # inside B (4-10): 3s into it
    assert labels(project) == ["A", "B (a)", "B (b)", "C"]
    left, right = project.timeline[1], project.timeline[2]
    assert (left.start, left.end) == (10, 13)
    assert (right.start, right.end) == (13, 16)
    assert project.timeline.total_duration == 13    # splitting never changes length


def test_split_rejects_boundaries_and_out_of_range(project):
    with pytest.raises(TimelineError):
        project.split_at(4)                         # exactly a clip boundary
    with pytest.raises(TimelineError):
        project.split_at(0)
    with pytest.raises(TimelineError):
        project.split_at(500)
    assert len(project.timeline) == 3               # failed edits change nothing
    assert project.history.undo_labels()[0] == "Add 'C'"   # failed edits aren't recorded


def test_delete(project):
    project.delete_clip(project.timeline[1].id)
    assert labels(project) == ["A", "C"]
    assert project.timeline.total_duration == 7
    with pytest.raises(ClipNotFound):
        project.delete_clip("nope")

"""Project = timeline + undo/redo history + export queue. Store = all projects."""
from __future__ import annotations

import itertools
from typing import Dict, List, Optional

from .history import AddClip, DeleteClip, History, MoveClip, SplitAt, TrimClip
from .jobs import PRIORITIES, ExportQueue
from .timeline import Timeline, TimelineError


class Project:
    def __init__(self, pid: str, name: str):
        name = name.strip()
        if not name:
            raise TimelineError("project name must not be empty")
        self.id, self.name = pid, name
        self.timeline = Timeline()
        self.history = History()
        self.exports = ExportQueue()

    # every edit goes through history.execute so it is undoable
    def add_clip(self, label, start, end, index: Optional[int] = None):
        clip = self.timeline.new_clip(label, start, end)
        self.history.execute(AddClip(clip, index), self.timeline)
        return clip

    def delete_clip(self, clip_id):
        self.history.execute(DeleteClip(clip_id), self.timeline)

    def move_clip(self, clip_id, to_index):
        self.history.execute(MoveClip(clip_id, to_index), self.timeline)

    def trim_clip(self, clip_id, start=None, end=None):
        self.history.execute(TrimClip(clip_id, start, end), self.timeline)

    def split_at(self, at):
        self.history.execute(SplitAt(at), self.timeline)

    def undo(self):
        return self.history.undo(self.timeline)

    def redo(self):
        return self.history.redo(self.timeline)

    def queue_export(self, priority=3, name=""):
        return self.exports.submit(self.timeline.layout(), self.timeline.total_duration,
                                   priority, name)

    def process_next_export(self):
        return self.exports.process_next()

    def state(self) -> dict:
        return {
            "id": self.id, "name": self.name,
            "clips": self.timeline.layout(),
            "total_duration": self.timeline.total_duration,
            "can_undo": self.history.can_undo, "can_redo": self.history.can_redo,
            "undo_stack": self.history.undo_labels(),
            "redo_stack": self.history.redo_labels(),
            "export_pending": self.exports.pending(),
            "export_done": self.exports.finished(),
            "priorities": {str(k): v for k, v in PRIORITIES.items()},
        }


class ProjectStore:
    """In-memory projects (a dict gives O(1) lookup by id). Data resets on restart."""

    def __init__(self) -> None:
        self._projects: Dict[str, Project] = {}
        self._ids = itertools.count(1)

    def create(self, name: str) -> Project:
        project = Project(f"p{next(self._ids)}", name)
        self._projects[project.id] = project
        return project

    def get(self, pid: str) -> Project:
        try:
            return self._projects[pid]
        except KeyError:
            raise LookupError(f"no project with id {pid!r}")

    def list(self) -> List[dict]:
        return [{"id": p.id, "name": p.name} for p in self._projects.values()]

"""
Timeline: an ordered sequence of clips.

DATA STRUCTURES USED HERE
-------------------------
* Array-backed list (Python ``list``) of clips, in playback order.
    Why: a timeline is read far more often than it is edited, and the UI renders
    it in full every time. A contiguous array gives O(1) indexing and the best
    cache behaviour. Insert/remove/move cost O(n), which is fine for the few
    hundred clips a project has. (A linked list would make a *move* O(1) once
    you hold the node, but finding the node is O(n) anyway and it would make the
    binary search below impossible, since a linked list has no random access.)

* Parallel array of cumulative start offsets (a prefix-sum array).
    ``offsets[i]`` is where clip i begins on the timeline. Clips are laid out
    back-to-back (a "magnetic" timeline), so offsets are *sorted by
    construction*, which is exactly what binary search needs. It is rebuilt in
    O(n) after every edit, so lookups stay O(log n).

* Binary search (``bisect``) over ``offsets``.
    "Which clip is playing at t = 12.5 s?" is answered in O(log n) instead of a
    linear scan. Splitting at a timestamp uses this same lookup.

TIME MODEL
----------
A Clip's ``start``/``end`` are the in-point/out-point inside its source media
(in seconds). Its duration is ``end - start``. Timeline position is *derived*
from clip order and durations, so reordering clips automatically re-flows them.
"""
from __future__ import annotations

import bisect
import itertools
from dataclasses import dataclass
from typing import Iterator, List, Optional, Tuple

PRECISION = 3          # times are kept to millisecond precision
MIN_DURATION = 0.001   # a clip can never be shorter than 1 ms


class TimelineError(ValueError):
    """Invalid edit (bad times, out-of-range index, ...)."""


class ClipNotFound(LookupError):
    """No clip with the requested id."""


def _num(x) -> float:
    try:
        return round(float(x), PRECISION)
    except (TypeError, ValueError):
        raise TimelineError(f"not a number: {x!r}")


@dataclass(frozen=True)
class Clip:
    """Immutable clip. Immutability makes undo trivial: we keep the old object
    and swap it back, with no risk of it having been mutated in between."""
    id: str
    label: str
    start: float
    end: float

    def __post_init__(self):
        label = str(self.label).strip()
        if not label:
            raise TimelineError("label must not be empty")
        start, end = _num(self.start), _num(self.end)
        if start < 0:
            raise TimelineError("start must be >= 0")
        if end - start < MIN_DURATION - 1e-9:
            raise TimelineError("end must be greater than start")
        object.__setattr__(self, "label", label)
        object.__setattr__(self, "start", start)
        object.__setattr__(self, "end", end)

    @property
    def duration(self) -> float:
        return round(self.end - self.start, 6)


class Timeline:
    def __init__(self) -> None:
        self._clips: List[Clip] = []        # array-backed ordered sequence
        self._offsets: List[float] = []     # sorted prefix sums (binary-search key)
        self._total: float = 0.0
        self._ids = itertools.count(1)

    # ---- basics -----------------------------------------------------------
    def new_clip(self, label: str, start: float, end: float) -> Clip:
        return Clip(f"c{next(self._ids)}", label, start, end)

    def next_id(self) -> str:
        return f"c{next(self._ids)}"

    def __len__(self) -> int:
        return len(self._clips)

    def __iter__(self) -> Iterator[Clip]:
        return iter(self._clips)

    def __getitem__(self, i: int) -> Clip:
        return self._clips[i]

    @property
    def total_duration(self) -> float:
        return self._total

    def _rebuild(self) -> None:
        """O(n) prefix-sum rebuild; keeps ``_offsets`` sorted for bisect."""
        offsets, running = [], 0.0
        for clip in self._clips:
            offsets.append(round(running, 6))
            running += clip.duration
        self._offsets, self._total = offsets, round(running, 6)

    def _check_index(self, i: int, upper: int) -> None:
        if not isinstance(i, int) or not 0 <= i < upper:
            raise TimelineError(f"index {i!r} out of range")

    # ---- primitive mutations (every edit command is built from these) ------
    def insert(self, clip: Clip, index: Optional[int] = None) -> int:
        """Insert at ``index`` (default: end). O(n). Returns the index used."""
        if index is None:
            index = len(self._clips)
        if not isinstance(index, int) or not 0 <= index <= len(self._clips):
            raise TimelineError(f"index {index!r} out of range")
        self._clips.insert(index, clip)
        self._rebuild()
        return index

    def remove_at(self, index: int) -> Clip:
        self._check_index(index, len(self._clips))
        clip = self._clips.pop(index)
        self._rebuild()
        return clip

    def replace_at(self, index: int, clip: Clip) -> Clip:
        self._check_index(index, len(self._clips))
        old, self._clips[index] = self._clips[index], clip
        self._rebuild()
        return old

    def move(self, src: int, dst: int) -> None:
        """Reorder: remove from ``src`` and re-insert so it ends up at ``dst``."""
        self._check_index(src, len(self._clips))
        self._check_index(dst, len(self._clips))
        self._clips.insert(dst, self._clips.pop(src))
        self._rebuild()

    # ---- lookups ----------------------------------------------------------
    def index_of(self, clip_id: str) -> int:
        """Linear scan, O(n). Ids are unordered, and indices shift on every
        edit, so a map would need constant re-indexing for no real gain."""
        for i, clip in enumerate(self._clips):
            if clip.id == clip_id:
                return i
        raise ClipNotFound(f"no clip with id {clip_id!r}")

    def find_at(self, t: float) -> Tuple[int, Clip, float]:
        """Which clip is under timeline time ``t``? O(log n) binary search.

        Returns (index, clip, seconds_into_clip). ``bisect_right`` finds the
        first offset > t; the clip just before it is the one containing t.
        """
        t = _num(t)
        if not self._clips or not 0 <= t < self._total:
            raise TimelineError(f"time {t} is outside the timeline (0 to {self._total})")
        i = bisect.bisect_right(self._offsets, t) - 1
        return i, self._clips[i], round(t - self._offsets[i], 6)

    def layout(self) -> List[dict]:
        """The timeline in order, with derived positions, ready for display."""
        out = []
        for i, clip in enumerate(self._clips):
            begin = self._offsets[i]
            out.append({
                "id": clip.id, "label": clip.label, "index": i,
                "start": clip.start, "end": clip.end, "duration": clip.duration,
                "timeline_start": begin,
                "timeline_end": round(begin + clip.duration, 6),
            })
        return out

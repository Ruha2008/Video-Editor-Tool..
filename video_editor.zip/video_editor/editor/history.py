"""
Undo/redo via the Command pattern and two stacks.

DATA STRUCTURES USED HERE
-------------------------
* Two stacks (LIFO): ``_undo`` and ``_redo``.
    Why: undo must reverse the *most recent* edit first, then the one before it;
    that is exactly last-in-first-out. Push/pop are O(1). Undoing moves a
    command from the undo stack to the redo stack; doing a brand-new edit
    clears the redo stack (the "future" it described no longer exists).

* ``collections.deque(maxlen=N)`` as the stack storage.
    A deque gives O(1) append/pop at the right end and silently drops the
    *oldest* entry when full, so history is bounded without an O(n) slice.

Each Command knows how to ``do`` itself and ``undo`` itself. They store just
enough state (old clip objects, indices, generated ids) so that redoing after an
undo reproduces exactly the same result, including the same ids for split clips.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from collections import deque
from dataclasses import replace
from typing import Deque, List, Optional

from .timeline import MIN_DURATION, Clip, Timeline, TimelineError, _num


class Command(ABC):
    label: str = ""

    @abstractmethod
    def do(self, tl: Timeline) -> None: ...

    @abstractmethod
    def undo(self, tl: Timeline) -> None: ...


class AddClip(Command):
    def __init__(self, clip: Clip, index: Optional[int] = None):
        self.clip, self.index, self._at = clip, index, None
        self.label = f"Add '{clip.label}'"

    def do(self, tl):
        self._at = tl.insert(self.clip, self.index)

    def undo(self, tl):
        tl.remove_at(self._at)


class DeleteClip(Command):
    def __init__(self, clip_id: str):
        self.clip_id, self._at, self._clip = clip_id, None, None
        self.label = "Delete clip"

    def do(self, tl):
        self._at = tl.index_of(self.clip_id)
        self._clip = tl.remove_at(self._at)
        self.label = f"Delete '{self._clip.label}'"

    def undo(self, tl):
        tl.insert(self._clip, self._at)


class MoveClip(Command):
    def __init__(self, clip_id: str, to_index: int):
        self.clip_id, self.to, self._from = clip_id, to_index, None
        self.label = "Move clip"

    def do(self, tl):
        self._from = tl.index_of(self.clip_id)
        tl.move(self._from, self.to)
        self.label = f"Move '{tl[self.to].label}' to position {self.to + 1}"

    def undo(self, tl):
        tl.move(self.to, self._from)


class TrimClip(Command):
    """Change a clip's in-point and/or out-point (either may be omitted)."""

    def __init__(self, clip_id: str, start: Optional[float], end: Optional[float]):
        self.clip_id, self.start, self.end = clip_id, start, end
        self._at, self._old, self._new = None, None, None
        self.label = "Trim clip"

    def do(self, tl):
        if self._new is None:                      # first run: validate + compute
            at = tl.index_of(self.clip_id)
            old = tl[at]
            new = replace(old,
                          start=old.start if self.start is None else self.start,
                          end=old.end if self.end is None else self.end)
            if new == old:
                raise TimelineError("trim changes nothing")
            self._at, self._old, self._new = at, old, new
            self.label = f"Trim '{old.label}'"
        tl.replace_at(self._at, self._new)

    def undo(self, tl):
        tl.replace_at(self._at, self._old)


class SplitAt(Command):
    """Split whatever clip is under timeline time ``at`` into two clips."""

    def __init__(self, at: float):
        self.at = _num(at)
        self._at = self._orig = self._left = self._right = None
        self.label = f"Split at {self.at}s"

    def do(self, tl):
        if self._left is None:                     # first run: binary search + build
            i, clip, into = tl.find_at(self.at)    # O(log n)
            cut = _num(clip.start + into)          # cut point in source time
            if cut - clip.start < MIN_DURATION - 1e-9 or clip.end - cut < MIN_DURATION - 1e-9:
                raise TimelineError("that time is already a clip boundary")
            self._at, self._orig = i, clip
            self._left = Clip(tl.next_id(), f"{clip.label} (a)", clip.start, cut)
            self._right = Clip(tl.next_id(), f"{clip.label} (b)", cut, clip.end)
        tl.replace_at(self._at, self._left)
        tl.insert(self._right, self._at + 1)

    def undo(self, tl):
        tl.remove_at(self._at + 1)
        tl.replace_at(self._at, self._orig)


class History:
    def __init__(self, limit: int = 200):
        self._undo: Deque[Command] = deque(maxlen=limit)   # stack
        self._redo: Deque[Command] = deque(maxlen=limit)   # stack

    def execute(self, cmd: Command, tl: Timeline) -> None:
        cmd.do(tl)                 # if this raises, nothing is recorded
        self._undo.append(cmd)     # push
        self._redo.clear()         # a new edit invalidates the redo "future"

    def undo(self, tl: Timeline) -> Command:
        if not self._undo:
            raise TimelineError("nothing to undo")
        cmd = self._undo.pop()
        cmd.undo(tl)
        self._redo.append(cmd)
        return cmd

    def redo(self, tl: Timeline) -> Command:
        if not self._redo:
            raise TimelineError("nothing to redo")
        cmd = self._redo.pop()
        cmd.do(tl)
        self._undo.append(cmd)
        return cmd

    @property
    def can_undo(self) -> bool:
        return bool(self._undo)

    @property
    def can_redo(self) -> bool:
        return bool(self._redo)

    def undo_labels(self) -> List[str]:
        """Most recent first (top of the stack)."""
        return [c.label for c in reversed(self._undo)]

    def redo_labels(self) -> List[str]:
        return [c.label for c in reversed(self._redo)]

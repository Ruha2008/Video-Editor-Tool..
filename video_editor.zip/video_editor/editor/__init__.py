"""Video editor core: DSA-driven timeline, undo/redo history and export queue."""

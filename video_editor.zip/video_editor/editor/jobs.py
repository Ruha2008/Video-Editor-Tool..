"""
Export job queue.

DATA STRUCTURE USED HERE
------------------------
* Binary min-heap priority queue (``heapq``).
    Why: exports are not strictly first-come-first-served; a user can mark an
    export "urgent". A heap gives O(log n) submit and O(log n) pop-min, always
    returning the most urgent job. Ties are broken by a monotonically
    increasing sequence number, which makes equal-priority jobs behave as a
    plain FIFO queue.

A job captures an immutable *snapshot* of the timeline when it is submitted, so
later edits (or undo) never change what an already-queued export will produce.
"""
from __future__ import annotations

import heapq
import itertools
from dataclasses import dataclass
from typing import Dict, List, Tuple

from .timeline import TimelineError

PRIORITIES = {1: "urgent", 2: "high", 3: "normal", 4: "low"}


def timecode(seconds: float) -> str:
    ms = int(round(seconds * 1000))
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"


@dataclass
class ExportJob:
    id: str
    name: str
    priority: int
    seq: int
    clips: Tuple[dict, ...]            # snapshot of timeline.layout()
    total: float
    status: str = "queued"             # queued -> done
    result: str = ""

    def to_dict(self) -> dict:
        return {"id": self.id, "name": self.name, "priority": self.priority,
                "priority_name": PRIORITIES[self.priority], "status": self.status,
                "clip_count": len(self.clips), "total": self.total, "result": self.result}


class ExportQueue:
    def __init__(self) -> None:
        self._heap: List[Tuple[int, int, str]] = []   # (priority, seq, job_id)
        self._jobs: Dict[str, ExportJob] = {}
        self._seq = itertools.count(1)

    def submit(self, layout: List[dict], total: float, priority: int = 3, name: str = "") -> ExportJob:
        if priority not in PRIORITIES:
            raise TimelineError(f"priority must be one of {sorted(PRIORITIES)}")
        if not layout:
            raise TimelineError("cannot export an empty timeline")
        seq = next(self._seq)
        job = ExportJob(f"j{seq}", name.strip() or f"Export {seq}", priority, seq,
                        tuple(layout), total)
        self._jobs[job.id] = job
        heapq.heappush(self._heap, (priority, seq, job.id))      # O(log n)
        return job

    def process_next(self) -> ExportJob:
        """'Render' the most urgent job. The render is simulated: it writes an
        EDL-style text listing, which keeps the project free of media deps."""
        if not self._heap:
            raise TimelineError("export queue is empty")
        _, _, job_id = heapq.heappop(self._heap)                  # O(log n)
        job = self._jobs[job_id]
        lines = [f"TITLE: {job.name}", f"DURATION: {timecode(job.total)}", ""]
        for n, c in enumerate(job.clips, 1):
            lines.append(
                f"{n:03d}  {c['label']}  SRC {timecode(c['start'])} - {timecode(c['end'])}"
                f"  REC {timecode(c['timeline_start'])} - {timecode(c['timeline_end'])}")
        job.result, job.status = "\n".join(lines), "done"
        return job

    def pending(self) -> List[dict]:
        """Queued jobs in the order they will run (sorted copy; heap untouched)."""
        return [self._jobs[j].to_dict() for _, _, j in sorted(self._heap)]

    def finished(self) -> List[dict]:
        return [j.to_dict() for j in self._jobs.values() if j.status == "done"]

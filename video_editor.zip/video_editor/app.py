"""Flask app: JSON API + a single-page front end. Run:  python app.py"""
import math
import threading

from flask import Flask, jsonify, render_template, request

from editor.project import ProjectStore


def _num(body, key, required=True):
    if body.get(key) in (None, ""):
        if required:
            raise ValueError(f"'{key}' is required")
        return None
    try:
        v = float(body[key])
    except (TypeError, ValueError):
        raise ValueError(f"'{key}' must be a number")
    if not math.isfinite(v):
        raise ValueError(f"'{key}' must be a finite number")
    return v


def _int(body, key, required=True):
    v = _num(body, key, required)
    if v is None:
        return None
    if v != int(v):
        raise ValueError(f"'{key}' must be a whole number")
    return int(v)


def create_app():
    app = Flask(__name__)
    store = ProjectStore()
    lock = threading.Lock()          # Flask's dev server is threaded; serialise edits

    def respond(fn, status=200):
        try:
            with lock:
                return jsonify(fn()), status
        except LookupError as e:
            return jsonify(error=str(e.args[0])), 404
        except ValueError as e:      # includes TimelineError
            return jsonify(error=str(e)), 400

    def body():
        return request.get_json(silent=True) or {}

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/projects")
    def list_projects():
        return respond(store.list)

    @app.post("/api/projects")
    def create_project():
        return respond(lambda: store.create(str(body().get("name", ""))).state(), 201)

    @app.get("/api/projects/<pid>")
    def get_project(pid):
        return respond(lambda: store.get(pid).state())

    def edit(pid, action, status=200):
        def run():
            project = store.get(pid)
            action(project)
            return project.state()
        return respond(run, status)

    @app.post("/api/projects/<pid>/clips")
    def add_clip(pid):
        b = body()
        return edit(pid, lambda p: p.add_clip(b.get("label", ""), _num(b, "start"),
                                              _num(b, "end"), _int(b, "index", False)), 201)

    @app.delete("/api/projects/<pid>/clips/<cid>")
    def delete_clip(pid, cid):
        return edit(pid, lambda p: p.delete_clip(cid))

    @app.post("/api/projects/<pid>/clips/<cid>/move")
    def move_clip(pid, cid):
        b = body()
        return edit(pid, lambda p: p.move_clip(cid, _int(b, "to_index")))

    @app.post("/api/projects/<pid>/clips/<cid>/trim")
    def trim_clip(pid, cid):
        b = body()
        return edit(pid, lambda p: p.trim_clip(cid, _num(b, "start", False), _num(b, "end", False)))

    @app.post("/api/projects/<pid>/split")
    def split(pid):
        b = body()
        return edit(pid, lambda p: p.split_at(_num(b, "at")))

    @app.post("/api/projects/<pid>/undo")
    def undo(pid):
        return edit(pid, lambda p: p.undo())

    @app.post("/api/projects/<pid>/redo")
    def redo(pid):
        return edit(pid, lambda p: p.redo())

    @app.get("/api/projects/<pid>/lookup")
    def lookup(pid):
        def run():
            t = _num(request.args, "t")
            i, clip, into = store.get(pid).timeline.find_at(t)   # binary search
            return {"index": i, "clip_id": clip.id, "label": clip.label,
                    "seconds_into_clip": into}
        return respond(run)

    @app.post("/api/projects/<pid>/exports")
    def queue_export(pid):
        b = body()
        priority = _int(b, "priority", False) or 3
        return edit(pid, lambda p: p.queue_export(priority, str(b.get("name", ""))), 201)

    @app.post("/api/projects/<pid>/exports/process")
    def process_export(pid):
        return edit(pid, lambda p: p.process_next_export())

    return app


if __name__ == "__main__":
    create_app().run(debug=True, port=5000)
